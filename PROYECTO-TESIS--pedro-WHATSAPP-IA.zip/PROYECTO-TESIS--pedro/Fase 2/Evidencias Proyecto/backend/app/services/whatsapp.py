from twilio.rest import Client

from app.config import settings


def _client() -> Client:
    if not settings.twilio_account_sid or not settings.twilio_auth_token:
        raise RuntimeError("Credenciales de Twilio no configuradas")
    return Client(settings.twilio_account_sid, settings.twilio_auth_token)


def send_whatsapp_message(to: str, body: str) -> str:
    message = _client().messages.create(
        from_=settings.twilio_whatsapp_number,
        to=to if to.startswith("whatsapp:") else f"whatsapp:{to}",
        body=body,
    )
    return message.sid
