from __future__ import annotations

from uuid import UUID
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy.engine import Connection
from twilio.request_validator import RequestValidator
from twilio.twiml.messaging_response import MessagingResponse

from app.ai.agent import generate_agent_decision
from app.config import settings
from app.database import get_db
from app.repositories import (
    create_whatsapp_visit,
    fetch_active_whatsapp_conversation,
    fetch_or_create_whatsapp_client,
    fetch_whatsapp_history,
    insert_whatsapp_message,
)
from app.services.whatsapp import send_whatsapp_message

router = APIRouter(prefix="/webhooks", tags=["whatsapp"])


def _validate_twilio(request: Request, form: dict[str, str]) -> None:
    if not settings.twilio_validate_signature:
        return
    if not settings.twilio_auth_token:
        raise HTTPException(status_code=500, detail="TWILIO_AUTH_TOKEN no está configurado")
    if not settings.twilio_webhook_url:
        raise HTTPException(status_code=500, detail="TWILIO_WEBHOOK_URL no está configurada")
    signature = request.headers.get("X-Twilio-Signature", "")
    validator = RequestValidator(settings.twilio_auth_token)
    if not validator.validate(settings.twilio_webhook_url, form, signature):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Firma de Twilio inválida")


@router.post("/whatsapp")
async def whatsapp_webhook(request: Request, db: Connection = Depends(get_db)) -> Response:
    form_data = await request.form()
    form = {str(k): str(v) for k, v in form_data.items()}
    _validate_twilio(request, form)

    from_number = form.get("From", "")
    body = form.get("Body", "").strip()
    if not from_number or not body:
        return Response(content=str(MessagingResponse()), media_type="application/xml")

    try:
        client = fetch_or_create_whatsapp_client(db, from_number, UUID(settings.killbichos_empresa_id))
        conversation = fetch_active_whatsapp_conversation(db, client["id"])
        insert_whatsapp_message(db, conversation["id"], "cliente", body)
        history = fetch_whatsapp_history(db, conversation["id"], limit=20)

        decision = await generate_agent_decision(history, client["nombre"], client.get("direccion"))
        intent = decision["intent"]
        reply = decision["reply"]

        if decision["action"] == "create_appointment":
            appointment_datetime = decision.get("appointment_datetime")
            if not appointment_datetime:
                reply = "Claro 😊 Para agendar necesito que me indiques una fecha y una hora concreta."
            else:
                try:
                    visit = create_whatsapp_visit(
                        db,
                        UUID(settings.killbichos_empresa_id),
                        client["id"],
                        appointment_datetime,
                        decision.get("notes"),
                    )
                    when = visit["fecha_hora"].astimezone(ZoneInfo("America/Santiago"))
                    action_text = "quedó agendada" if visit["created"] else "ya estaba agendada"
                    reply = (
                        f"Perfecto 😊 Tu visita {action_text} para el "
                        f"{when.strftime('%d/%m/%Y a las %H:%M')} (hora de Chile)."
                    )
                except Exception:
                    db.rollback()
                    reply = "Entendí que quieres agendar una visita, pero no pude registrarla ahora. Un operador deberá ayudarte con la reserva."

        insert_whatsapp_message(db, conversation["id"], "agente_ia", reply, intent)

        # Respondemos por TwiML: Twilio entrega el mensaje sin una segunda llamada HTTP.
        response = MessagingResponse()
        response.message(reply)
        return Response(content=str(response), media_type="application/xml")
    except RuntimeError as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail="Error procesando el mensaje de WhatsApp") from exc
