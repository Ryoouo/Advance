from __future__ import annotations

import json
from datetime import datetime
from zoneinfo import ZoneInfo

import httpx

from app.config import settings

SANTIAGO = ZoneInfo("America/Santiago")

SYSTEM_PROMPT = """
Eres el agente conversacional de Kill Bichos, empresa chilena de control de plagas.
Tu trabajo es atender clientes por WhatsApp de forma amable, breve y natural.

Reglas:
- Habla en español claro, cordial y chileno neutro.
- No inventes disponibilidad ni confirmes una visita si el backend no la crea.
- Si el cliente quiere agendar, necesitas una fecha y una hora concretas. Si falta una, pregunta.
- Si el cliente dice 'mañana', 'este viernes', etc., conviértelo usando la fecha actual proporcionada.
- Para consultas generales responde directamente sin inventar precios, horarios comerciales o servicios no indicados.
- Si el cliente pide cancelar/reagendar, no ejecutes cambios todavía: indícale que un operador debe confirmar la modificación.
- Devuelve SIEMPRE JSON válido con exactamente estas claves:
  action, intent, reply, appointment_datetime, notes

Valores permitidos para action: reply, create_appointment.
intent debe ser una cadena corta como consulta, agendar_visita, confirmar_horario, reagendar, cancelar.
apointment_datetime debe ser ISO 8601 con zona horaria de Chile si action=create_appointment; en otro caso null.
notes debe ser texto breve o null.
"""


def _extract_json(text: str) -> dict:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:].strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("La IA no devolvió JSON")
    return json.loads(text[start:end + 1])


async def generate_agent_decision(history: list[dict], client_name: str, client_address: str | None) -> dict:
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY no está configurada")

    now = datetime.now(SANTIAGO)
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "system",
            "content": (
                f"Fecha y hora actual en Santiago de Chile: {now.isoformat()}. "
                f"Cliente: {client_name}. Dirección registrada: {client_address or 'no registrada'}."
            ),
        },
    ]
    for item in history:
        messages.append({
            "role": "user" if item["emisor"] == "cliente" else "assistant",
            "content": item["contenido"],
        })

    payload = {
        "model": settings.openai_model,
        "messages": messages,
        "temperature": 0.2,
        "response_format": {"type": "json_object"},
    }
    headers = {
        "Authorization": f"Bearer {settings.openai_api_key}",
        "Content-Type": "application/json",
    }
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post("https://api.openai.com/v1/chat/completions", json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()

    content = data["choices"][0]["message"]["content"]
    result = _extract_json(content)
    return {
        "action": result.get("action", "reply"),
        "intent": result.get("intent", "consulta"),
        "reply": result.get("reply", "No pude procesar tu solicitud."),
        "appointment_datetime": result.get("appointment_datetime"),
        "notes": result.get("notes"),
    }
