from pydantic_settings import BaseSettings, SettingsConfigDict


# Lee JWT_SECRET, DATABASE_URL y ALLOWED_ORIGINS desde el archivo .env (o
# desde variables de entorno reales en producción). Así ningún secreto queda
# escrito en el código fuente.
class Settings(BaseSettings):
    jwt_secret: str = "desarrollo-cambia-esta-clave"
    database_url: str = "postgresql+psycopg://killbichos:killbichos_dev@localhost:5432/killbichos"
    allowed_origins: str = "http://localhost:3000,http://localhost:5173"
    openai_api_key: str = ""
    openai_model: str = "gpt-4.1-mini"
    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_whatsapp_number: str = ""
    twilio_webhook_url: str = ""
    twilio_validate_signature: bool = True
    killbichos_empresa_id: str = "11111111-1111-1111-1111-111111111111"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
